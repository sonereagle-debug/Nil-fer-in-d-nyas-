# Nilüfer'in Dünyası

Flutter tabanlı pastel karakter giydirme ve oda dekorasyon oyunu.

## Codemagic
- Framework: Flutter
- Build mode: Release
- Android artifact: APK
- Entry point: lib/main.dart

Bu başlangıç sürümünde ana menü, karakter giydirme, oda dekorasyonu ve mini oyun ekranları bulunur.
